# drrobot_jaguar4x4_player
The project is for Jaguar 4x4 robot before 2014. This project need DrRobotMotionSensorDriver project. Please fork or copy these 2 project to your catkin working space under ROS.
